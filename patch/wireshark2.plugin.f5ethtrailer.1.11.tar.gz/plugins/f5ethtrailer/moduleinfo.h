/*
 * F5 Ethernet Trailer Dissector Plugin Copyright 2016 F5 Networks
 */

/* Included *after* config.h, in order to re-define these macros */

#ifdef PACKAGE
#undef PACKAGE
#endif

/* Name of package */
#define PACKAGE "f5ethtrailer"


#ifdef VERSION
#undef VERSION
#endif

/* Version number of package */
#define VERSION "0.1.11"

